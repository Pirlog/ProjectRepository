﻿#pragma strict

public var Spiked1 : boolean=false;
public var Spiked2 : boolean=false;
public var Spiked3 : boolean=false;
public var Spiked4 : boolean=false;
public var Spiked5 : boolean=false;
public var Spiked6 : boolean=false;
public var RayHitBox1 : Transform;
public var RayHitBox2 : Transform;
public var RayHitBox3 : Transform;
public var RayHitBox4 : Transform;
public var RayHitBox5 : Transform;
public var RayHitBox6 : Transform;
public var StartLine : Transform;
public var camera_suivre : GameObject;
public var zposition_end : float;
public var yposition_end : float;
public var ecran_fin : GameObject;
public var player : GameObject;
static var mort : boolean=false;
static var uneseulefois : boolean = true;

function Update () {

Spiked1 = Physics2D.Linecast(StartLine.position, RayHitBox1.position, 1<< LayerMask.NameToLayer("Spike") );
Spiked2 = Physics2D.Linecast(StartLine.position, RayHitBox2.position, 1<< LayerMask.NameToLayer("Spike") );
Spiked3 = Physics2D.Linecast(StartLine.position, RayHitBox3.position, 1<< LayerMask.NameToLayer("Spike") );
Spiked4 = Physics2D.Linecast(StartLine.position, RayHitBox4.position, 1<< LayerMask.NameToLayer("Spike") );
Spiked5 = Physics2D.Linecast(StartLine.position, RayHitBox5.position, 1<< LayerMask.NameToLayer("Spike") );
Spiked6 = Physics2D.Linecast(StartLine.position, RayHitBox6.position, 1<< LayerMask.NameToLayer("Spike") );
 
 if  (Spiked1 == true || Spiked2 == true || Spiked3 == true || Spiked4 == true || Spiked5 == true || Spiked6 == true){
 		
 		ecran_fin.transform.position.y = camera_suivre.transform.position.y - 0.2; // Affiche l'écran de fin, mettre la camera dans camera_suivre.
        ecran_fin.transform.position.x = camera_suivre.transform.position.x;
        ecran_fin.transform.position.z = camera_suivre.transform.position.z+5; 
 		
 		player.SetActive(false);
 		mort = true;
 		
 		if (uneseulefois == true){
 		Rejouer.Ptdevie = Rejouer.Ptdevie - 1;
 		uneseulefois = false;
 		}
 		
 		// gameObject.SetActive (false); On peut désactiver totalement un gameObject de cette manière.
 		
  }
}

﻿#pragma strict

public var perdu : boolean;
public var player : GameObject;
public var menu : GameObject;
static var Ptdevie : int = 3;
static var justonesec : boolean = false;

function Update () {
 
 if (SpikeCollision.mort ==! true ) {
 if (Input.GetKeyUp(KeyCode.R)){
 
       Ptdevie = Ptdevie - 1;
       
    if (Controller.Checkpoint2 == true && Ptdevie > 0){
 		player.transform.position.x = 11;
    	player.transform.position.y = -13;
    	menu.transform.position.x = -60;
   	 	menu.transform.position.y = -15;
    	SpikeCollision.mort = false;
    	Controller.DejaTouche = false;
    	Controller.moveSpeed = 8f;
    	Controller.CarreOuRond = true;
    	player.SetActive(true);
    	}
 	else if (Controller.Checkpoint1 == true && Ptdevie > 0){
 		player.transform.position.x = 101;
    	player.transform.position.y = 6;
    	menu.transform.position.x = -60;
   	 	menu.transform.position.y = -15;
    	SpikeCollision.mort = false;
    	Controller.DejaTouche = false;
    	Controller.moveSpeed = 8f;
    	Controller.CarreOuRond = true;
    	player.SetActive(true);
    	}	
 	else {
 		justonesec = true;
 		player.transform.position.x = -13.52;
   	 	player.transform.position.y = 6.57;
    	menu.transform.position.x = -60;
   	 	menu.transform.position.y = -15;
    	SpikeCollision.mort = false;
    	Controller.DejaTouche = false;
    	Controller.DejaTouche2 = false;
    	Controller.moveSpeed = 8f;
    	Controller.CarreOuRond = true;
    	Controller.Checkpoint1 = false;
    	
    	if (Controller.Checkpoint2 == true) {
     CameraControl.resetZ = true;
     CameraControl.DejaTouche = false;
    }
    Controller.Checkpoint2 = false;
    	
    	if (Ptdevie < 1) {
    	Ptdevie = 3;
    	}
    	
    	Coeur_Bonus.reset = true;
    	player.SetActive(true);
  	}
   }
 }
 if (SpikeCollision.mort == true ){
 
   if (Input.GetKeyUp(KeyCode.Space) && Controller.Checkpoint2 == true && Ptdevie > 0) {
    player.transform.position.x = 11;
    player.transform.position.y = -13;
    menu.transform.position.x = -60;
    menu.transform.position.y = -15;
    SpikeCollision.mort = false;
    Controller.DejaTouche = false;
    SpikeCollision.uneseulefois = true;
    Controller.moveSpeed = 8f;
    Controller.CarreOuRond = true;
    player.SetActive(true);
   }
   else if (Input.GetKeyUp(KeyCode.Space) && Controller.Checkpoint1 == true && Ptdevie > 0) {
    player.transform.position.x = 101;
    player.transform.position.y = 6;
    menu.transform.position.x = -60;
    menu.transform.position.y = -15;
    SpikeCollision.mort = false;
    Controller.DejaTouche = false;
    SpikeCollision.uneseulefois = true;
    Controller.moveSpeed = 8f;
    Controller.CarreOuRond = true;
    player.SetActive(true);
   }
   else if (Input.GetKeyUp(KeyCode.Space)){
    player.transform.position.x = -13.52;
    player.transform.position.y = 6.57;
    menu.transform.position.x = -60;
    menu.transform.position.y = -15;
    SpikeCollision.mort = false;
    Controller.DejaTouche = false;
    Controller.DejaTouche2 = false;
    SpikeCollision.uneseulefois = true;
    Controller.Checkpoint1 = false;
    Controller.moveSpeed = 8f;
    Controller.CarreOuRond = true;
    
    if (Controller.Checkpoint2 == true) {
     CameraControl.resetZ = true;
     CameraControl.DejaTouche = false;
    }
    Controller.Checkpoint2 = false;
    
    if (Ptdevie < 1) {
    	Ptdevie = 3;
    	}
    	
    Coeur_Bonus.reset = true;
    player.SetActive(true);
  }
 }
}
﻿#pragma strict

var target : GameObject;
var zposition : float;
var yposition : float;
static var resetZ : boolean = false;
static var DejaTouche : boolean = false;

function Update() {
 
 if ( target != null ){
transform.position.y = target.transform.position.y;
transform.position.x = target.transform.position.x;
transform.position.z = zposition-10;
transform.position.y = yposition+5;

 if (resetZ == true){
 	zposition = zposition + 2;
 	resetZ = false;
   }

 if (target.transform.position.y < yposition - 5 && target.transform.position.x > 100) { // Condition lors du premier changement d'étage
 	yposition = -9.5;
 	
   }
 if (target.transform.position.y < -8 && target.transform.position.x < 16 && DejaTouche == false) { // Condition lors du deuxième changement d'étage
  yposition = -19.1;
  zposition = zposition - 2;
  DejaTouche = true;
   }
 if (Rejouer.Ptdevie < 1 || Rejouer.justonesec == true){
  yposition = 3.06;
  Rejouer.justonesec = false;
  	}
  }
}
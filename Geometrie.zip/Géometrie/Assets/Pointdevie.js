﻿#pragma strict

public var Coeur1 : GameObject;
public var Coeur2 : GameObject;
public var Coeur3 : GameObject;
public var target : GameObject;

function Update () {

transform.position.x = target.transform.position.x - 14.5; 
transform.position.y = target.transform.position.y + 8.7;

 if (Rejouer.Ptdevie > 3){
 	Rejouer.Ptdevie = 3;
 }
 if (Rejouer.Ptdevie == 3) {
 	Coeur1.SetActive(true);
 	Coeur2.SetActive(true);
 	Coeur3.SetActive(true);
 	}	
 else if (Rejouer.Ptdevie == 2) {
 	Coeur1.SetActive(true);
 	Coeur2.SetActive(true);
 	Coeur3.SetActive(false);
 }
 else if (Rejouer.Ptdevie == 1) {
 	Coeur1.SetActive(true);
 	Coeur2.SetActive(false);
 	Coeur3.SetActive(false);
 }
 else if (Rejouer.Ptdevie == 0) {
 	Coeur1.SetActive(false);
 	Coeur2.SetActive(false);
 	Coeur3.SetActive(false);
 }
}
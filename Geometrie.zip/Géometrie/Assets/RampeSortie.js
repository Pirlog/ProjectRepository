﻿#pragma strict

public var TouchTrigger : boolean = false;
public var StartLine : Transform;
public var RayHitBox1 : Transform;

function Update () {

TouchTrigger = Physics2D.Linecast(StartLine.position, RayHitBox1.position, 1<< LayerMask.NameToLayer("RampeS") );
	
		if (TouchTrigger == true) {
		 Controller.moveSpeed = 8f;
	 	 Controller.CarreOuRond = true;
		}
  	}
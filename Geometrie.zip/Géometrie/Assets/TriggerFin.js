﻿#pragma strict

public var StartLine : Transform;
public var RayHitBox1 : Transform;
public var TouchTrigger : boolean = false;
public var ecran_fin : GameObject;
public var camera_suivre : GameObject;
public var player : GameObject;

function Update () {

TouchTrigger = Physics2D.Linecast(StartLine.position, RayHitBox1.position, 1<< LayerMask.NameToLayer("TriggFin") );

if (TouchTrigger == true) {
		
		ecran_fin.transform.position.y = camera_suivre.transform.position.y - 0.2; // Affiche l'écran de fin, mettre la camera dans camera_suivre.
        ecran_fin.transform.position.x = camera_suivre.transform.position.x;
        ecran_fin.transform.position.z = camera_suivre.transform.position.z+5;
        
        player.SetActive(false);
 }
}
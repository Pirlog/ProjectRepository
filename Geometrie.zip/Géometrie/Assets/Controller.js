#pragma strict

static var moveSpeed : float = 8f; 
public var grounded : boolean = false;
public var GroundedEnd : Transform;
public var NearGroundCaptor : Transform;
public var StartLine : Transform;
public var RayHitBox1 : Transform;
public var VelocityY : float = 20f;
static var CarreOuRond : boolean = true;
public var Carre : GameObject;
public var Rond : GameObject;
public var TouchTrigger : boolean = false;
public var TouchTrigger2 : boolean = false;
static var DejaTouche : boolean = false;
static var DejaTouche2 : boolean = false;
static var Checkpoint1 : boolean = false;
static var Checkpoint2 : boolean = false;
public var NearGround : boolean = false;

function Update () {

TouchTrigger = Physics2D.Linecast(StartLine.position, RayHitBox1.position, 1<< LayerMask.NameToLayer("Trigg") );
TouchTrigger2 = Physics2D.Linecast(StartLine.position, RayHitBox1.position, 1<< LayerMask.NameToLayer("Trigg2") );
	
	if (TouchTrigger == true && DejaTouche == false) {
	 moveSpeed = -8f;
	 DejaTouche = true;
	 Checkpoint1 = true; 
	}
	
	if (TouchTrigger2 == true && DejaTouche2 == false) {
	 moveSpeed = 8f;
	 DejaTouche2 = true;
	 Checkpoint2 = true;
	 Checkpoint1 = false;
	}
	
transform.Translate(Vector2.right * moveSpeed * Time.deltaTime);

if (CarreOuRond == true) {
	 
	Rond.SetActive(false);
	Carre.SetActive(true);

	grounded = Physics2D.Linecast(StartLine.position, GroundedEnd.position, 1<< LayerMask.NameToLayer("Ground") );
 		
 		//if (grounded == false) {  Tourner si le carré est en l'air
 		//transform.Rotate(0,0,VelocityRotate * Time.deltaTime);
 		//}
 		if (Input.GetKey(KeyCode.Space) && grounded == true){
 		rigidbody2D.velocity.y = VelocityY;
 		}
 	}
 
if (CarreOuRond == false) {
 	  
 	  Carre.SetActive(false);
 	  Rond.SetActive(true);
 	  
 	  NearGround = Physics2D.Linecast(StartLine.position, NearGroundCaptor.position, 1<< LayerMask.NameToLayer("NG") );
 	  
 	  if (Input.GetKey(KeyCode.Space) && NearGround == false){
 	  rigidbody2D.velocity.y = -VelocityY * 4;
 	  }
 	}		
 }
			
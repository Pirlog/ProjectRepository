﻿#pragma strict

public var TouchTrigger : boolean = false;
public var StartLine : Transform;
public var RayHitBox1 : Transform;

function Update () {

TouchTrigger = Physics2D.Linecast(StartLine.position, RayHitBox1.position, 1<< LayerMask.NameToLayer("RampeE") );
	
	if (TouchTrigger == true) {
		Controller.moveSpeed = 0.98 * Controller.moveSpeed;
	 	Controller.CarreOuRond = false;
	}
}
﻿#pragma strict

public var RayHitBox1 : Transform;
public var RayHitBox2 : Transform;
public var RayHitBox3 : Transform;
public var RayHitBox4 : Transform;
public var RayHitBox5 : Transform;
public var RayHitBox6 : Transform;
public var StartLine : Transform;
public var CoeurTouche1 : boolean=false;
public var CoeurTouche2 : boolean=false;
public var CoeurTouche3 : boolean=false;
public var CoeurTouche4 : boolean=false;
public var CoeurTouche5 : boolean=false;
public var CoeurTouche6 : boolean=false;
public var uneseulefois : boolean = true;
static var reset : boolean = false;
public var yposition : float;

function Update () {

CoeurTouche1 = Physics2D.Linecast(StartLine.position, RayHitBox1.position, 1<< LayerMask.NameToLayer("CoeurTouche") );
CoeurTouche2 = Physics2D.Linecast(StartLine.position, RayHitBox2.position, 1<< LayerMask.NameToLayer("CoeurTouche") );
CoeurTouche3 = Physics2D.Linecast(StartLine.position, RayHitBox3.position, 1<< LayerMask.NameToLayer("CoeurTouche") );
CoeurTouche4 = Physics2D.Linecast(StartLine.position, RayHitBox4.position, 1<< LayerMask.NameToLayer("CoeurTouche") );
CoeurTouche5 = Physics2D.Linecast(StartLine.position, RayHitBox5.position, 1<< LayerMask.NameToLayer("CoeurTouche") );
CoeurTouche6 = Physics2D.Linecast(StartLine.position, RayHitBox6.position, 1<< LayerMask.NameToLayer("CoeurTouche") );
 
 if  (CoeurTouche1 == true || CoeurTouche2 == true || CoeurTouche3 == true || CoeurTouche4 == true || CoeurTouche5 == true || CoeurTouche6 == true){
 	if (uneseulefois == true && Rejouer.Ptdevie < 3){
 		Rejouer.Ptdevie = Rejouer.Ptdevie + 1 ;
 		uneseulefois = false;
 		gameObject.SetActive(false);
 	}
 }
 if (reset == true) {
 	gameObject.SetActive(true);
 	reset = false;
 }
}
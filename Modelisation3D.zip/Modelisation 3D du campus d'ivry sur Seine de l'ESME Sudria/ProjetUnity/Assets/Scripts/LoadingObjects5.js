﻿#pragma strict

static var FirstTrigger_s : boolean;
static var OutOf_s : boolean;
public var AreaOne : GameObject;
public var AreaTwo : GameObject;

function Start () {
FirstTrigger_s = false;
}

function Update () {

}

function OnTriggerEnter (other : Collider){ 
		if (other.gameObject.tag == "Player" && FirstTrigger_s == false) {
		OutOf_s = true; 
		FirstTrigger_s = true;
		}
		if (other.gameObject.tag == "Player" && OutOf_s == false) {
		AreaOne.SetActive(true);
		AreaTwo.SetActive(false);
		FirstTrigger_s = false;
		}
		
	}
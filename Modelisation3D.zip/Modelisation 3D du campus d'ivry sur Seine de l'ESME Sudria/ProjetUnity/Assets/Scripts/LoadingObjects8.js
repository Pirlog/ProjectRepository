﻿#pragma strict

public var AreaOne : GameObject;
public var AreaTwo : GameObject;

function Start () {
LoadingObjects7.FirstTrigger_o = false;
}

function Update () {

}

function OnTriggerEnter (other : Collider){ 
		if (other.gameObject.tag == "Player" && LoadingObjects7.FirstTrigger_o == false) {
		LoadingObjects7.OutOf_o = false; 
		LoadingObjects7.FirstTrigger_o = true;
		}
		if (other.gameObject.tag == "Player" && LoadingObjects7.OutOf_o == true) {
		AreaOne.SetActive(false);
		AreaTwo.SetActive(true);
		LoadingObjects7.FirstTrigger_o = false;
		}
		
	}
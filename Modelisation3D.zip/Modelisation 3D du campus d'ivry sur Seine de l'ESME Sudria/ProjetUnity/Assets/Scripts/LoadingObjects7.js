﻿#pragma strict

static var FirstTrigger_o : boolean;
static var OutOf_o : boolean;
public var AreaOne : GameObject;
public var AreaTwo : GameObject;

function Start () {
FirstTrigger_o = false;
}

function Update () {

}

function OnTriggerEnter (other : Collider){ 
		if (other.gameObject.tag == "Player" && FirstTrigger_o == false) {
		OutOf_o = true; 
		FirstTrigger_o = true;
		}
		if (other.gameObject.tag == "Player" && OutOf_o == false) {
		AreaOne.SetActive(true);
		AreaTwo.SetActive(false);
		FirstTrigger_o = false;
		}
		
	}
﻿#pragma strict

static var FirstTrigger_t : boolean;
static var OutOf_t : boolean;
public var AreaOne : GameObject;
public var AreaTwo : GameObject;

function Start () {
FirstTrigger_t = false;
}

function Update () {

}

function OnTriggerEnter (other : Collider){ 
		if (other.gameObject.tag == "Player" && FirstTrigger_t == false) {
		OutOf_t = true; 
		FirstTrigger_t = true;
		}
		if (other.gameObject.tag == "Player" && OutOf_t == false) {
		AreaOne.SetActive(true);
		AreaTwo.SetActive(false);
		FirstTrigger_t = false;
		}
		
	}
﻿#pragma strict

public var AreaOne : GameObject;
public var AreaTwo : GameObject;

function Start () {
LoadingObjects1.FirstTrigger = false;
}

function Update () {

}

function OnTriggerEnter (other : Collider){ 
		if (other.gameObject.tag == "Player" && LoadingObjects1.FirstTrigger == false) {
		LoadingObjects1.OutOf = false; 
		LoadingObjects1.FirstTrigger = true;
		}
		if (other.gameObject.tag == "Player" && LoadingObjects1.OutOf == true) {
		AreaOne.SetActive(false);
		AreaTwo.SetActive(true);
		LoadingObjects1.FirstTrigger = false;
		}
		
	}
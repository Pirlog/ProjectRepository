﻿#pragma strict

public var AreaOne : GameObject;
public var AreaTwo : GameObject;

function Start () {
LoadingObjects5.FirstTrigger_s = false;
}

function Update () {

}

function OnTriggerEnter (other : Collider){ 
		if (other.gameObject.tag == "Player" && LoadingObjects5.FirstTrigger_s == false) {
		LoadingObjects5.OutOf_s = false; 
		LoadingObjects5.FirstTrigger_s = true;
		}
		if (other.gameObject.tag == "Player" && LoadingObjects5.OutOf_s == true) {
		AreaOne.SetActive(false);
		AreaTwo.SetActive(true);
		LoadingObjects5.FirstTrigger_s = false;
		}
		
	}
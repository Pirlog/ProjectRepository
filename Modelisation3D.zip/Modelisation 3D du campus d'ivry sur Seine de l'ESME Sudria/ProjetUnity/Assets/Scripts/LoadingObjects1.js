﻿#pragma strict

static var FirstTrigger : boolean;
static var OutOf : boolean;
public var AreaOne : GameObject;
public var AreaTwo : GameObject;

function Start () {
FirstTrigger = false;
}

function Update () {

}

function OnTriggerEnter (other : Collider){ 
		if (other.gameObject.tag == "Player" && FirstTrigger == false) {
		OutOf = true; 
		FirstTrigger = true;
		}
		if (other.gameObject.tag == "Player" && OutOf == false) {
		AreaOne.SetActive(true);
		AreaTwo.SetActive(false);
		FirstTrigger = false;
		}
		
	}
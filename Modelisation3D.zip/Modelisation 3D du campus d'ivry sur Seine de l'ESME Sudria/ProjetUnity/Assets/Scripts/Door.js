﻿#pragma strict

var smooth = 2.0;
var DoorOpenAngle = 90.0;
private var open : boolean;
private var enter : boolean;

private var defaultRot : Vector3;
private var openRot : Vector3;

function Start(){
defaultRot = transform.eulerAngles; // Prend les valeur de base des différentes valeur de rotation par rapport aux axes x,y, et z
openRot = new Vector3 (defaultRot.x, defaultRot.y + DoorOpenAngle, defaultRot.z); // Création du vecteur avec l'angle de rotation en Y défini
}

function Update (){
if(open){
//Open door
transform.eulerAngles = Vector3.Slerp(transform.eulerAngles, openRot, Time.deltaTime * smooth);
}else{
//Close door
transform.eulerAngles = Vector3.Slerp(transform.eulerAngles, defaultRot, Time.deltaTime * smooth);
}

if(Input.GetButtonDown("Fire1") && enter){ // Si le bouton Mapé Fire1 est enfoncé
open = !open;
}
}

function OnTriggerEnter (other : Collider){ // Si quelque chose entre dans la zone de Trigger de la porte
if (other.gameObject.tag == "Player") { // Et que ce qui entre a le Tag : Player
enter = true; // On donne la valeur "true" pour utiliser la fonction Update ( if (open) )
}
}

function OnTriggerExit (other : Collider){ // Si on sort de la zone Trigger de la porte
if (other.gameObject.tag == "Player") { // Et que ce qui est sorti a le Tag Player
enter = false; // On redonne la valeur "false" pour désactiver la fonction Update
}
}
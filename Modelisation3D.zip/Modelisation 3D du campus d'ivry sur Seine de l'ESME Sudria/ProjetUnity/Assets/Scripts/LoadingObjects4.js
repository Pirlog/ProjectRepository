﻿#pragma strict

public var AreaOne : GameObject;
public var AreaTwo : GameObject;

function Start () {
LoadingObjects3.FirstTrigger_t = false;
}

function Update () {

}

function OnTriggerEnter (other : Collider){ 
		if (other.gameObject.tag == "Player" && LoadingObjects3.FirstTrigger_t == false) {
		LoadingObjects3.OutOf_t = false; 
		LoadingObjects3.FirstTrigger_t = true;
		}
		if (other.gameObject.tag == "Player" && LoadingObjects3.OutOf_t == true) {
		AreaOne.SetActive(false);
		AreaTwo.SetActive(true);
		LoadingObjects3.FirstTrigger_t = false;
		}
		
	}
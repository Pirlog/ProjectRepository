﻿
//	cliquer sur  "Update Texture" après avoir changer la taille du cube

#if UNITY_EDITOR 
using UnityEditor;
#endif

using UnityEngine;
using System.Collections;


public class ReCalcCubeTexture : MonoBehaviour 
{
	
	Vector3 currentScale = new Vector3(); // création d'un vecteur taille
	
	void Start()
	{
		currentScale = transform.localScale; // on prend la valeur des "scales" du Cube 
	}

	void Update () {
		reCalcCubeTexture(); // On appel la fonction une fois par frame
	}
	
	public void reCalcCubeTexture()
	{

		if ( currentScale != transform.localScale ) // Si la taille de l'objet change en cours d'utilisation
		{
			
			currentScale = transform.localScale; // on reprend la bonne valeur des scales
			
		
			if ( currentScale == Vector3.one ) // si les scales sont (1,1,1) il n'y a pas besoin de gérer un MeshFilter
												//on revient donc au MeshFilter d'un Cube normal
			{
				
				GameObject cube = GameObject.CreatePrimitive( PrimitiveType.Cube );
				
				DestroyImmediate( GetComponent<MeshFilter>() );
				gameObject.AddComponent<MeshFilter>();
				GetComponent<MeshFilter>().sharedMesh = cube.GetComponent<MeshFilter>().sharedMesh;
				
				DestroyImmediate( cube );
				return;
				
			}
			

			
			float length = currentScale.x; // on enregistre les valeurs
			float width = currentScale.z; // des scales (x,y,z)
			float height = currentScale.y;
			
			Mesh mesh; // on créé un mesh
			
			#if UNITY_EDITOR
			MeshFilter meshFilter = GetComponent<MeshFilter>();
			Mesh meshCopy = ( Mesh ) Mesh.Instantiate( meshFilter.sharedMesh );
			mesh = meshFilter.mesh = meshCopy;
			#endif
			
			Vector2[] mesh_UVs = mesh.uv; // on créé son vecteur de taille par 
										//   rapport a la surface du Cube
			
			//On met a jour les tailles 
			//Devant
			mesh_UVs[ 2 ] = new Vector2( 0 , height );
			mesh_UVs[ 3 ] = new Vector2( length , height );
			mesh_UVs[ 0 ] = new Vector2( 0 , 0 );
			mesh_UVs[ 1 ] = new Vector2( length , 0 );
			
			
			//Derrière
			mesh_UVs[ 6 ] = new Vector2( 0 , height );
			mesh_UVs[ 7 ] = new Vector2( length , height );
			mesh_UVs[ 10 ] = new Vector2( 0 , 0 );
			mesh_UVs[ 11 ] = new Vector2( length , 0 );
			
			
			//A gauche
			mesh_UVs[ 19 ] = new Vector2( 0 , height );
			mesh_UVs[ 17 ] = new Vector2( width , height );
			mesh_UVs[ 16 ] = new Vector2( 0 , 0 );
			mesh_UVs[ 18 ] = new Vector2( width , 0 );
			
			
			//A droite
			mesh_UVs[ 23 ] = new Vector2( 0 , height );
			mesh_UVs[ 21 ] = new Vector2( width , height );
			mesh_UVs[ 20 ] = new Vector2( 0 , 0 );
			mesh_UVs[ 22 ] = new Vector2( width , 0 );
			
			
			//En haut
			mesh_UVs[ 4 ] = new Vector2( 0 , width );
			mesh_UVs[ 5 ] = new Vector2( length , width );
			mesh_UVs[ 8 ] = new Vector2( 0 , 0 );
			mesh_UVs[ 9 ] = new Vector2( length , 0 );
			
			
			//Et en bas
			mesh_UVs[ 15 ] = new Vector2( 0 , width );
			mesh_UVs[ 13 ] = new Vector2( length , width );
			mesh_UVs[ 12 ] = new Vector2( 0 , 0 );
			mesh_UVs[ 14 ] = new Vector2( length , 0 );
			
			//Enfin on applique ca au mesh
			mesh.uv = mesh_UVs;
			mesh.name = "Cube Instance";
			if ( GetComponent<Renderer>().sharedMaterial.mainTexture.wrapMode != TextureWrapMode.Repeat )
				GetComponent<Renderer>().sharedMaterial.mainTexture.wrapMode = TextureWrapMode.Repeat;
			
		}
	}
}


//Ceci est pour créer un boutton dans l' "inspector" de Unity
#if UNITY_EDITOR
[CustomEditor( typeof( ReCalcCubeTexture ) )]
public class UpdateTextures : Editor
{
	public override void OnInspectorGUI()
	{
		DrawDefaultInspector();
		
		ReCalcCubeTexture myScript = ( ReCalcCubeTexture ) target;
		if ( GUILayout.Button( "Update Texture" ) )
		{
			myScript.reCalcCubeTexture();
		}
	}
}
#endif